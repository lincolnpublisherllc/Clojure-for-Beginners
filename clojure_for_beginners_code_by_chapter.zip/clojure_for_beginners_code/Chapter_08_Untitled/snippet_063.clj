(defn remove-tag [contacts id tag]
  (update-contact contacts id #(update (ensure-tags %) :tags disj (keyword tag))))