(defn find-contacts [contacts {:keys [q tags]}]
  (->> contacts
       (cond-> q    (search q)