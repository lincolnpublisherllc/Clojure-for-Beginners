(into {} (map (fn [[k v]] [k (* v 2)]) {:a 1 :b 2}))
;; => {:a 2 :b 4}