(contains? #{:a :b} :a)              ;; => true
(contains? #{:a :b} :z)              ;; => false