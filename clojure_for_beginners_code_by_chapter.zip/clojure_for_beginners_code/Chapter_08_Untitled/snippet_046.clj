;; cleaner: explicit logic
(defn upsert-item [cart sku title price qty]
  (let [new (item title price qty)]
    (update cart sku
            (fn [old]
              (if old
                (-> old
                    (assoc :title (:title new) :price (:price new))
                    (update :qty + (:qty new)))