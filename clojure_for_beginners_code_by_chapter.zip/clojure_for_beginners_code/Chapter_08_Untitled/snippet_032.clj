(defn find-by-id [contacts id]
  (first (filter #(= (:id %) id) contacts)))