(get {:x 1 :y 2} :x)                   ;; => 1
({:x 1 :y 2} :y)                       ;; => 2 (maps are callable by key)
(:x {:x 1 :y 2})                       ;; => 1 (keywords are callable too)