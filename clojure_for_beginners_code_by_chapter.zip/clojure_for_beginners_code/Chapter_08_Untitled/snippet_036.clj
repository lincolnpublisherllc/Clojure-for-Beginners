(defn upsert-index [index c]
  (assoc index (:id c) (mk-contact c)))