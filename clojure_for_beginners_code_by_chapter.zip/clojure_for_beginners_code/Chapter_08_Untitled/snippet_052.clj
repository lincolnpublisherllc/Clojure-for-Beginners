(defn render [cart]
  (let [ls (lines cart)