(def contacts
  (-> []
      (add-contact {:id 1 :first "Ada" :last "Lovelace" :phone "111"})
      (add-contact {:id 2 :first "Bo"  :last "Lee"      :email "bo@ex.com"})))