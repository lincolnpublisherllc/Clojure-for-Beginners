(assoc  {:n 1} :n 2)                  ;; map replace
(update {:n 1} :n inc)