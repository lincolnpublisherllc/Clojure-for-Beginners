    (str (str/join "\n" ls)
         (when (seq ls) "\n")
         (format "TOTAL: $%.2f" total))))