;; add to the end
(conj [1 2] 3)          ;; => [1 2 3]