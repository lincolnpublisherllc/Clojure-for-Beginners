(find-by-id contacts 2)
;; => {:id 2, :first "bo", :last "lee", ...}