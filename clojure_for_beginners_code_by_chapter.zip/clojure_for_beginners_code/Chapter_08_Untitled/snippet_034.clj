(defn delete-contact [contacts id]
  (vec (remove #(= (:id %) id) contacts)))