(defn index-by-id [contacts]
  (into {} (map (fn [c] [(:id c) c]) contacts)))