(defn remove-item [cart sku]
  (dissoc cart sku))