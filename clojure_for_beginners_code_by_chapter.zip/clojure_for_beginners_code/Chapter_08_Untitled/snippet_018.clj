(set/union    #{1 2} #{2 3})         ;; => #{1 2 3}
(set/intersection #{1 2} #{2 3})     ;; => #{2}
(set/difference  #{1 2 3} #{2})      ;; => #{1 3}