(map (fn [[n a]] {:name n :age a})
     (map vector (:name input) (:age input)))
;; => ({:name "Ada" :age 36} {:name "Bo" :age 28})
(group-by :city