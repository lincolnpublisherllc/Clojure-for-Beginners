(defn add-contact [contacts c]
  (conj contacts (mk-contact c)))