(def contacts2
  (update-contact contacts 2 #(assoc % :phone "222")))