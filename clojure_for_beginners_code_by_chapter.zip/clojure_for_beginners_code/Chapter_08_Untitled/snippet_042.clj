(defn display [c]
  (format "#%-3s %-10s %-12s  %s  %s"
          (:id c)
          (str/capitalize (:first c))
          (str/capitalize (:last  c))
          (or (:phone c) "")
          (or (:email c) "")))