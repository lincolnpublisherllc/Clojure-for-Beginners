(defn matches? [q c]
  (let [q (clojure.string/lower-case q)
        hay (->> [(:first c) (:last c) (:email c) (:phone c)]
                 (map str)
                 (clojure.string/join " " )