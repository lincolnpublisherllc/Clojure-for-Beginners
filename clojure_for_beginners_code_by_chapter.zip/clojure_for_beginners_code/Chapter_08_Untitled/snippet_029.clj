(defn normalize-name [s]
  (-> s str/trim str/lower-case))