(conj [1 2] 3)                 ;; vector append
(conj '(2 3) 1)                ;; list prepend
(assoc {:a 1} :b 2)            ;; map add/replace key
(conj #{:x} :y)                ;; set add unique
(assoc  [10 20] 0 11)                ;; index update
(update [10 20] 1 inc)