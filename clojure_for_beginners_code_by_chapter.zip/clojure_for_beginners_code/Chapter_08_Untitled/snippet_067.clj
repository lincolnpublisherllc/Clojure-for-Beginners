(defn with-tags [contacts tags]
  (let [want (set (map keyword tags))]
    (filter #(not-empty (clojure.set/intersection want (:tags %))) contacts)))