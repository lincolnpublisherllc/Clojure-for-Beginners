(defn add-tag [contacts id tag]
  (update-contact contacts id #(update (ensure-tags %) :tags conj (keyword tag))))