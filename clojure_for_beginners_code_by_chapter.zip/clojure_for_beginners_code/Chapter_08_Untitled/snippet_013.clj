(def user {:id 1 :profile {:name "Ada" :city "Lagos"}})
(get-in user [:profile :city])                   ;; => "Lagos"
(assoc-in user [:profile :city] "Abuja")         ;; replace nested
(update-in user [:profile :name] clojure.string/upper-case)