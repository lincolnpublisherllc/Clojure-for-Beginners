(map inc [1 2 3])                      ;; => (2 3 4)
(filter even? #{1 2 3 4})              ;; => (2 4)
(reduce + (vals {:a 1 :b 2 :c 3}))     ;; => 6
(map key {:a 1 :b 2})                  ;; => (:a :b)
(map val  {:a 1 :b 2})                 ;; => (1 2)