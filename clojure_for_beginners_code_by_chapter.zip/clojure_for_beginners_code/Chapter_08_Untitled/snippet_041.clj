(index-by-id contacts2)
;; => {1 {...} 2 {...}}