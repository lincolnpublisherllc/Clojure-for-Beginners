(defn update-contact [contacts id f]
  (mapv (fn [c] (if (= (:id c) id) (f c) c)) contacts))