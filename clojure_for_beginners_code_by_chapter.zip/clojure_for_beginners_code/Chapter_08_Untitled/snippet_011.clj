;; remove a key
(dissoc {:a 1 :b 2} :a)                ;; => {:b 2}