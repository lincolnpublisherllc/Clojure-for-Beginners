(defn cart-total [cart]
  (reduce + (map (comp item-total val) cart)))