(defn set-qty [cart sku qty]
  (if (pos? qty)
    (assoc-in cart [sku :qty] qty)
    (remove-item cart sku)))