;; add to front
(conj '(2 3) 1)         ;; => (1 2 3)