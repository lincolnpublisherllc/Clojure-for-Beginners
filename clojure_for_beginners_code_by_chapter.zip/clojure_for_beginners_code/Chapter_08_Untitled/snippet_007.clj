;; update by index
(assoc [10 20 30] 1 25) ;; => [10 25 30]
(update [10 20 30] 2 inc) ;; => [10 20 31]