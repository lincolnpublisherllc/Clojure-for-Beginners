(defn lines [cart]
  (for [[sku it] cart]
    (format "%-8s  %-18s  %3d × $%6.2f  =  $%7.2f"
            (name sku) (:title it) (:qty it) (:price it) (item-total it))))