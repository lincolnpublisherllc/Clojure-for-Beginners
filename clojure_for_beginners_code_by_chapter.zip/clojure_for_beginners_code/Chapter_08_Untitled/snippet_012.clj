;; update a value with a function
(update {:count 3} :count inc)         ;; => {:count 4}
(update {:tags ["a"]} :tags conj "b")  ;; => {:tags ["a" "b"]}