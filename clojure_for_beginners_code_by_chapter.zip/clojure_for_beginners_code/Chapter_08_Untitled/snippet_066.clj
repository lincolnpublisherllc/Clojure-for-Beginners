(defn search [contacts q]
  (filter #(matches? q %) contacts))