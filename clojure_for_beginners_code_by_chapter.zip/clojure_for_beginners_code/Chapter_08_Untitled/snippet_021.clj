(assoc-in  {:a {:b 1}} [:a :b] 2)
(update-in {:a {:b 1}} [:a :b] inc)
(get  [10 20 30] 1)                   ;; => 20
(nth  [10 20 30] 2)                   ;; => 30