;; => {1 {:id 1 :n "a"}, 2 {:id 2 :n "b"}}
(vec (set ["a" "a" "b" "c" "b"]))  ;; order not guaranteed