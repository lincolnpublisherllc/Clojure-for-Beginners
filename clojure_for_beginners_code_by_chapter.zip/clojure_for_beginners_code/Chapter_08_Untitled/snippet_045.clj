(defn add-item [cart sku title price qty]
  (update cart sku
          (fnil (fn [_] (item title price qty)) {})
          ;; if exists, merge and increase quantity
          ;; we want to replace title/price and add qty
          ))