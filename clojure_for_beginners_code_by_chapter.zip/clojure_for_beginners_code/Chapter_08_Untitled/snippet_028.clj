(ns app.contacts
  (:require [clojure.string :as str]))