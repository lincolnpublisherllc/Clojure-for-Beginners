(defn item-total [{:keys [price qty]}]
  (* price qty))