(defn delete-from-index [index id]
  (dissoc index id))