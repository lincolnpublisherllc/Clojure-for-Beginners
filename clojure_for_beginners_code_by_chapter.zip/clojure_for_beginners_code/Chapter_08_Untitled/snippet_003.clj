;; take first element and the rest
(first '(1 2 3))        ;; => 1
(rest  '(1 2 3))        ;; => (2 3)