(defn ensure-tags [c]
  (update c :tags #(if (set? %) % (set %))))