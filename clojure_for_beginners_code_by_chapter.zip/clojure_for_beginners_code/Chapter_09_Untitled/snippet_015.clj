(-> {:a {:b 2}}
    (update-in [:a :b :c] inc))  ;; fails