(or (presence "  ") "<empty>")   ;; => "<empty>"
(defn get* [m k default]
  (if (contains? m k)
    (get m k)