(defn safe-div [a b]
  (/ a b))