(slurp "missing.txt")
;; FileNotFoundException