(update-in {:a {:b 2}} [:a :b] (fnil inc 0))
;; => {:a {:b 3}}