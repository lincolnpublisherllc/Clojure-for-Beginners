(defn try-slurp [path]
  (try