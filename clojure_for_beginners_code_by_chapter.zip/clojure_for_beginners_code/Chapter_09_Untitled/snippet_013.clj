(parse-long* "123" 0)   ;; => 123
(parse-long* "" 0)      ;; => 0
(defn presence [s]
  (let [t (when s (.trim (str s)))]
    (when (seq t) t)))