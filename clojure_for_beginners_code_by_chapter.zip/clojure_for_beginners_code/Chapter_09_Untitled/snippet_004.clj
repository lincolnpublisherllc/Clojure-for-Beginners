(defn safe-div [a b]
  (if (zero? b)