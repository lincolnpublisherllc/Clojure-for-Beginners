(defn greet [name] (str "Hello, " name))
(greet)     ;; ArityException Wrong number of args (0) passed to: my.ns/greet