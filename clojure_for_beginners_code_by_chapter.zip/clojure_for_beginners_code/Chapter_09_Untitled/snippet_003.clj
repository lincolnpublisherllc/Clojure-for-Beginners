(require 'my.math :reload)
(my.math/safe-div 10 2)  ;; => 5
(my.math/safe-div 10 0)  ;; boom