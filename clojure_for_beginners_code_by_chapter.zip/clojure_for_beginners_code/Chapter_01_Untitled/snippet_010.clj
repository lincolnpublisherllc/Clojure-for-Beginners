(def names ["Amara" "Dee" "Sam"])
(->> names
     (map greet)
     (str/join "\n"))