(defn greet [name]
  (str "Welcome, " name "!"))