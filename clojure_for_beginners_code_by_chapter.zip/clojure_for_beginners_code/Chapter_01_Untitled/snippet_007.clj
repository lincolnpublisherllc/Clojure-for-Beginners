(import '(java.time LocalDate))
(.toString (LocalDate/now))