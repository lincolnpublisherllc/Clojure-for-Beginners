(def pi 3.14159)
(* 2 pi 5)  ;; circumference of a circle with radius 5 => 31.4159