(defn greet [name]
  (str "Hello, " name "!"))