(def scores [78 82 91 88])
(->> scores
     (map inc)       ;; add 1 to each score
     (filter odd?)   ;; keep odd numbers
     (reduce +))     ;; sum them
;; => 263