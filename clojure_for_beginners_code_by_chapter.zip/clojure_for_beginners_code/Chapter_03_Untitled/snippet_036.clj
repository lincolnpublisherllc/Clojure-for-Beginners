(= "a" "a")
(not= 1 2)
(and true false)
(or false "fallback")