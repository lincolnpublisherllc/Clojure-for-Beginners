(defn ask-name []
  (println "What is your name?")
  (flush)
  (let [name (read-line)]
    (println (greet name))))