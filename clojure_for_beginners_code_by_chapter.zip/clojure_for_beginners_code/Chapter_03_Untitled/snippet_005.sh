clj -X:run
clj -X:run :style '"shout"' :name '"Clojure"'
clj -X:run :style '"fancy"' :name '"Amara"'