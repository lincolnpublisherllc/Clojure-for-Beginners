(ns hello.core
  (:require [clojure.string :as str]))