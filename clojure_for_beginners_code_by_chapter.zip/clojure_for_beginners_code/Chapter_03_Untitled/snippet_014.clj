(->> ["Ada" "Bo" "Chi"]
     (map greet)
     (map clojure.string/upper-case)
     (clojure.string/join ", "))