(defn -main [& args]
  (let [name (or (first args) "World")]
    (println (greet name))))