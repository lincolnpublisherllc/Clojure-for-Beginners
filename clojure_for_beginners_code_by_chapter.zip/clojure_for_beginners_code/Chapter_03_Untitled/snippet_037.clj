(str "Hello, " "Clojure")
(clojure.string/upper-case "Ada")
(clojure.string/join ", " ["A" "B" "C"])