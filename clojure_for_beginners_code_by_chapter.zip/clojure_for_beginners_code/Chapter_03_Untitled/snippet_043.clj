(defn run-many [{:keys [names sep]}]
  (let [ns  (or names ["Ada" "Bo" "Chi"])