(if (> 3 2) "yes" "no")
(cond
  (< 2 1) "small"
  (= 2 2) "equal"