(defn -main [& args]
  ;; Very simple parser:
  ;; first arg is style, second is name. Both optional.
  (let [style (first args)