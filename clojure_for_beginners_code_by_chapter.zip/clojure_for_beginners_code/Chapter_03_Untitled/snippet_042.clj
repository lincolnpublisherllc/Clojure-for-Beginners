(defn multi-greet [names]
  (map greet names))