clj -M -m hello.core shout Clojure
clj -M -m hello.core fancy Amara