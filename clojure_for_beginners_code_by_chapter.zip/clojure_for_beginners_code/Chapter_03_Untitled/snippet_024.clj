(defn greeting-message [name]
  (str "Hello, " name "!"))