clj -X:many
clj -X:many :names '["Ayo","Sade"]' :sep '"; "'