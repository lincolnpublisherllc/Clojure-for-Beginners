(defn shout-greet [name]
  (str/upper-case (greet name)))