(defn run [{:keys [name style]}]
  (let [n (or name "World")