(defn run-input []
  (println "What is your name?")
  (flush)
  (let [name (read-line)]
    (println (greeting-message name))))