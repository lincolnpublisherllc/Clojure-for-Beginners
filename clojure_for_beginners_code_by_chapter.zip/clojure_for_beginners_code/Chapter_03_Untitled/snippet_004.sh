clj -M -m hello.core
clj -M -m hello.core Ada