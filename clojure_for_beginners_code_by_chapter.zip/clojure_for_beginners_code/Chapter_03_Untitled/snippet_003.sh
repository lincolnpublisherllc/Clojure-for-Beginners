clj -X:run
clj -X:run :name '"Ada"'