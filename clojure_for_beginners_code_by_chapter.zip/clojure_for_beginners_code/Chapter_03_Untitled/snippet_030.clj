(defn fancy-greet [name]
  (format "« Hello, %s! »" name))