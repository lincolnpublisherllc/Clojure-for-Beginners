(defn run [{:keys [name]}]
  (println (greet (or name "World"))))