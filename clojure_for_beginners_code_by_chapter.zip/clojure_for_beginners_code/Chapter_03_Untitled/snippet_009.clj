(require 'hello.core)
(hello.core/greet "Amara")