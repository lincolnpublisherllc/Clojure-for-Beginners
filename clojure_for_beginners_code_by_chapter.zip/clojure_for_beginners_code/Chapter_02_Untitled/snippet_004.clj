(defn -main [& args]
  (println (greet (or (first args) "friend"))))