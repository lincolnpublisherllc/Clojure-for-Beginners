sudo apt update
sudo apt install -y temurin-21-jdk || sudo apt install -y openjdk-21-jdk
java -version