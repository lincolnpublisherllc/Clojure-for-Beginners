(require '[hello.core :as h])
(h/greet "Sam")
(def numbers [1 2 3 4 5])
(map #(* % % ) numbers)