(defn square [x] (* x x))
(defn cubesum [xs] (reduce + (map #(* % % %) xs)))