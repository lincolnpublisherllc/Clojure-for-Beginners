(require 'number.tools)
(number.tools/square 12)
(number.tools/cubesum [1 2 3 4])