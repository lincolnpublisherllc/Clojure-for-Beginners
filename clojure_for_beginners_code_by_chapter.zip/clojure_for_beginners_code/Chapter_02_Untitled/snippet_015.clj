(ns practice.core)
(defn triple [x] (* 3 x))
Start a REPL and call (require 'practice.core) then (practice.core/triple 7).