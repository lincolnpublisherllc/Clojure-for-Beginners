(defn run [{:keys [n]}]
  (let [nums (range 1 (inc n))]
    (println "Squares:" (map square nums))
    (println "Sum of cubes from 1 to" n ":" (cubesum nums))))