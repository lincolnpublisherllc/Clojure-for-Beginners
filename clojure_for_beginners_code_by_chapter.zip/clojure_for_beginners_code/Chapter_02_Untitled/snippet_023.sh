lein run
lein repl