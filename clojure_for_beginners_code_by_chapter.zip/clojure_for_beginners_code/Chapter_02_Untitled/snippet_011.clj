(ns lein-hello.core
  (:gen-class))