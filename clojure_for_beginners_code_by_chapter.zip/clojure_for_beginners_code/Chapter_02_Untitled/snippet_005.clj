(require 'hello.core)
(hello.core/greet "Ada")