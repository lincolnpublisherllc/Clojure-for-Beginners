(+ 1 2 3)
(str "Hello, " "Clojure")
(map inc [1 2 3])