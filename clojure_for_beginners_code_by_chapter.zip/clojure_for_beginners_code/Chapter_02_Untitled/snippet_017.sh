java -version
clj -Sdescribe