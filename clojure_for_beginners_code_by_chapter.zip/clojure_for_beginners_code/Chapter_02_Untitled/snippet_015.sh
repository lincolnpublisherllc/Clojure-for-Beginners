scoop install leiningen
lein version
brew install leiningen
lein version