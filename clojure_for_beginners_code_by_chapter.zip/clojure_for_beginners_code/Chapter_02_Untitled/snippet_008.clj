(defn greet-exec [{:keys [name]}]
  (println (greet (or name "friend"))))