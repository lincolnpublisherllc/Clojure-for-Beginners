brew install clojure/tools/clojure
clj -Sdescribe