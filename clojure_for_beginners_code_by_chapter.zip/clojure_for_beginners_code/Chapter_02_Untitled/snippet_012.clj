(defn -main [& args]
  (println "Welcome from Leiningen!"))