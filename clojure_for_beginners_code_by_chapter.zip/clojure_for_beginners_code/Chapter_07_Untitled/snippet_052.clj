  (->> items
       (map #(if upper? (str/upper-case %) %))
       (map #(str prefix %))
       (str/join sep)))