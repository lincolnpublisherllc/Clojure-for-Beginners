(util.text/title-case "  my FIRST   title ")
;; => "My First Title"