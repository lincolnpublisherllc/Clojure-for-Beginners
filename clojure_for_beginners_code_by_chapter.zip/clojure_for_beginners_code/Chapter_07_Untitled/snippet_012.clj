(format-name {:first "ada" :last "lovelace" :title "Dr."})
;; => "Dr. Ada Lovelace"