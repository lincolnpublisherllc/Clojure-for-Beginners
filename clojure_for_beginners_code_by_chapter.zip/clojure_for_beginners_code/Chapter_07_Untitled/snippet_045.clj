    (cond
      (zero? n) 0.0
      (odd? n)  (double (v mid))