(defn line [{:keys [name score grade]}]
  (format "%-12s  %3d  %s" name score grade))