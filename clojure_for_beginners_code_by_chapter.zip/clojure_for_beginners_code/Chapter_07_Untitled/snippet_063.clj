(defn render [{:keys [rows summary]}]
  (let [{:keys [counts avg]} summary