(util.text/slug "Clojure & You: A Starter Guide!")
;; => "clojure-you-a-starter-guide"