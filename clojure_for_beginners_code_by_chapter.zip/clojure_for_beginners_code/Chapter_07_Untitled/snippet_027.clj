(defn long-word? [s] (>= (count s) 5))
(filter long-word? ["sun" "cloud" "rainbow"]) ;; => ("cloud" "rainbow")