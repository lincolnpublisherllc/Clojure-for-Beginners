(ns util.format
  (:require [clojure.string :as str]))