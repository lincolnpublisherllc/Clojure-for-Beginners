(vec (map inc [1 2 3])) ;; => [2 3 4]
(filter even? [1 2 3 4 5 6]) ;; => (2 4 6)