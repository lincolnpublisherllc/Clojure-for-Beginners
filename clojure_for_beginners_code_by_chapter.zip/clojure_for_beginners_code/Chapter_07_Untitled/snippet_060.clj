(defn summarize [rows]
  (let [grades (map :grade rows)