(util.text/tidy "  hello   WORLD ")
;; => "hello WORLD"