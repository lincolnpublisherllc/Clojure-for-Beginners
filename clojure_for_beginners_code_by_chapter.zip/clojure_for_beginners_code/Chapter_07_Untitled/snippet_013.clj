(defn area-rect [{:keys [w h]}]
  (* w h))