(ns util.text
  (:require [clojure.string :as str]))