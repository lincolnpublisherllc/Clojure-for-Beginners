  (let [mu (mean xs)
        ;; unbiased sample std dev is a later topic; keep it simple here