(defn join-words [sep & words]
  (clojure.string/join sep words))