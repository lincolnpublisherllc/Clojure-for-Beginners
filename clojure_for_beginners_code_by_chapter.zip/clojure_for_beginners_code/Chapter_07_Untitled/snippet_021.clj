(defn total [prices] (reduce + prices))
(defn print-total [prices] (println "Total:" (total prices)))