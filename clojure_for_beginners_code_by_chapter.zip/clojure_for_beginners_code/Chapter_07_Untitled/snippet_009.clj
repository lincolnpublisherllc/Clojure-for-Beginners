(join-words ", " "red" "green" "blue")
;; => "red, green, blue"