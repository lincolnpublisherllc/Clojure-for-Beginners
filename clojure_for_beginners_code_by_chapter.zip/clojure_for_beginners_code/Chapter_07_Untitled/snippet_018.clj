(let [x 10]
  (+ x 5))   ;; => 15
;; x is not visible outside