(defn decorate [{:keys [name score] :as m}]
  (assoc m :grade (letter score)))