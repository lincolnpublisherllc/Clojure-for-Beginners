(map inc [1 2 3])                 ;; => (2 3 4)
(map clojure.string/upper-case ["a" "b"]) ;; => ("A" "B")