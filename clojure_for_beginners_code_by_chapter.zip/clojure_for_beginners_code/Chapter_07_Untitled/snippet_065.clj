(defn run [{:keys [lines]}]
  (let [rows    (->> lines (map parse-row) (map decorate))