(defn tidy [s]
  (-> s str/trim (str/replace #"\s+" " ")))