    (if (pos? sigma)
      (map #(/ (- % mu) sigma) xs)
      (repeat (count xs) 0.0))))