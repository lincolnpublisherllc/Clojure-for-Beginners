(defn classify [n]
  (cond
    (neg? n) "negative"
    (zero? n) "zero"