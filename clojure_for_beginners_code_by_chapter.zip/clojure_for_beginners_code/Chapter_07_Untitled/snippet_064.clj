                    (get counts "A" 0) (get counts "B" 0)
                    (get counts "C" 0) (get counts "D" 0)
                    (get counts "F" 0))]
    (str hdr "\n"
         (str/join "\n" (map line rows)))))