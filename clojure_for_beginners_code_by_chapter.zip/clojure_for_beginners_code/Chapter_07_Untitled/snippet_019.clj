(def rate 0.1)
(defn net [price]
  (let [rate 0.07]         ;; shadows top-level rate
    (- price (* price rate))))