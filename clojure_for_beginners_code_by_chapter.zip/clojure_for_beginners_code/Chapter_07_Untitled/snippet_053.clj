(bullets ["alpha" "beta" "gamma"] {})
;; "- alpha\n- beta\n- gamma"
(bullets ["alpha" "beta"] {:upper? true :prefix "* " :sep " | "})
;; "* ALPHA | * BETA"