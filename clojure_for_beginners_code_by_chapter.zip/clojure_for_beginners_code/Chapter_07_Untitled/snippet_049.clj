(util.num/mean [2 4 9])     ;; => 5.0
(util.num/median [3 1 2 4]) ;; => 2.5
(take 3 (util.num/zscore [1 2 3 4 5]))