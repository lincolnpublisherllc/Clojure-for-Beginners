(defn format-name [{:keys [first last title]}]
  (str (when title (str title " "))
       (clojure.string/capitalize first)