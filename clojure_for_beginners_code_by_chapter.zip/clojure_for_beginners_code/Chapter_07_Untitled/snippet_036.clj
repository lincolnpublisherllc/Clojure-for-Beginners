  (->> (str/split (tidy s) #" ")
       (map (fn [w]
              (str (str/upper-case (subs w 0 1))
                   (str/lower-case (subs w 1)))))
       (str/join " ")))