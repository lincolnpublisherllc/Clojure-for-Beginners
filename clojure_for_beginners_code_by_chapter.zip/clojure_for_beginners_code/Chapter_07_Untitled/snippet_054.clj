(ns report.core
  (:require [clojure.string :as str]))