  (-> (tidy s)
      (str/lower-case)
      (str/replace #"[^a-z0-9]+" "-")
      (str/replace #"^-+|-+$" "")))