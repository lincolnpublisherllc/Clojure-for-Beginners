(defn discount [price rate]
  (let [off (* price rate)]
    (- price off)))