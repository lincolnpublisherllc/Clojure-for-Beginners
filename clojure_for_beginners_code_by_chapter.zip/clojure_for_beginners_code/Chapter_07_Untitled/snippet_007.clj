  ([name] (greet name "!"))
  ([name punct] (str "Hello, " name punct)))
(greet "Bo")        ;; => "Hello, Bo!"
(greet "Bo" "!!!")  ;; => "Hello, Bo!!!"