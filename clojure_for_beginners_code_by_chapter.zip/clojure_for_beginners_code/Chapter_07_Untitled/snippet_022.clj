#(+ % 10)          ;; one argument
#(+ %1 %2 %3)      ;; multiple arguments