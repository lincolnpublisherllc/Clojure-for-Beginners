(defn greet []
  (println "Enter your name:")
  (flush)
  (let [n (read-line)]
    (println "Hello," (str/trim n) "!")))
(defn run-command [cmd]
  (case cmd