(grade-label 92) ;; => "A-"
(grade-label 88) ;; => "B+"
(defn class-summary [scores]
  (let [grades   (map grade-label scores)