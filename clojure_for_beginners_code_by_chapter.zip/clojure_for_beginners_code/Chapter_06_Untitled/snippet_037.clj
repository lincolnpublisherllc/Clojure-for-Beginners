(defn show-summary [scores]
  (let [{:keys [avg counts]} (class-summary scores)]
    (println (summary-line {:avg avg :counts counts}))))