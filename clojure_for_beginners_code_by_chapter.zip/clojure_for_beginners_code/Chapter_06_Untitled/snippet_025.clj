(class-summary [98 82 76 76 59 90 88])
;; => {:grades ["A" "B+" "C" "C" "F" "A-" "B+"]
;;     :counts {\A 2, \B 2, \C 2, \F 1}
;;     :avg 81}
(defn summary-line [{:keys [avg counts]}]
  (let [status (cond
                 (>= avg 90) "Excellent"
                 (>= avg 80) "Strong"
                 (>= avg 70) "Satisfactory"