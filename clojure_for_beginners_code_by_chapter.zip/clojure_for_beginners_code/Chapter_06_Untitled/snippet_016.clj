(defn sum [xs]
  (loop [xs xs