(defn grade-label [score]
  (str (letter-grade score) (grade-band score)))