(let [age 17]
  (if (>= age 18)