(day-type :sat)
;; => "weekend"