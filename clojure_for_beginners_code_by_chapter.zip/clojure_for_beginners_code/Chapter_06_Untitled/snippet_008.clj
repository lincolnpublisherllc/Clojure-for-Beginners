(defn day-type [d]
  (case d