(defn count-down [n]
  (loop [i n]
    (if (pos? i)
      (do
        (println i)
        (recur (dec i)))