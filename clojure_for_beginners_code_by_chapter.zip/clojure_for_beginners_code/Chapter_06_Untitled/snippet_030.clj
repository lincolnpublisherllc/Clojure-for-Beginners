(defn show-time []
  (println "Time now:" (str (java.time.LocalTime/now))))