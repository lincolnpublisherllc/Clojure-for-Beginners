(count-down 3)
;; prints 3 2 1 on separate lines, returns "done"