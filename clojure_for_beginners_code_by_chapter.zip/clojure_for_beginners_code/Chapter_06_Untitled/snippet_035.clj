(ns app.gradebook
  (:require [clojure.string :as str]))