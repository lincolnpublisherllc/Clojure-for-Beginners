(ns app.menu
  (:require [clojure.string :as str]))