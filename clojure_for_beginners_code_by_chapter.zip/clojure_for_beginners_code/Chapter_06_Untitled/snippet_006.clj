(defn temperature-label [t]
  (cond
    (< t 0)     "freezing"
    (< t 10)    "cold"
    (< t 20)    "cool"
    (< t 30)    "warm"