;; Try it:
;; (menu-loop)