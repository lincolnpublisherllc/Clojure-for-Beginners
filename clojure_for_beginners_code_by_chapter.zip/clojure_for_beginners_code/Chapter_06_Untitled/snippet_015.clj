(sum-to 5)
;; => 15