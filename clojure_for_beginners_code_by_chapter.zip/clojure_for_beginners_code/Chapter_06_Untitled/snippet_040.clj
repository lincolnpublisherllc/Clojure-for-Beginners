(defn run-gradebook []
  (loop [scores []]
    (println)
    (println "Gradebook")
    (println "1) Add score")
    (println "2) Show summary")
    (println "q) Quit")
    (print   "Choice: ")
    (flush)
    (let [cmd (read-line)]
      (case cmd