    (println "Unknown option. Try again.")))
(defn menu-loop []
  (loop []
    (println)
    (println "Menu")
    (println "1) Show time")
    (println "2) Greet")
    (println "q) Quit")
    (print   "Choice: ")
    (flush)
    (let [cmd (read-line)