      (if (= result :quit)
        (println "Goodbye.")
        (recur)))))