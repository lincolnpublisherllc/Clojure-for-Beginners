(temperature-label 18)
;; => "cool"