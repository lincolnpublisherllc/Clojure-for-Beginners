(defn parse-score [s]
  (try
    (let [n (Long/parseLong (str/trim s))]
      (when (<= 0 n 100) n))
    (catch Exception _ nil)))