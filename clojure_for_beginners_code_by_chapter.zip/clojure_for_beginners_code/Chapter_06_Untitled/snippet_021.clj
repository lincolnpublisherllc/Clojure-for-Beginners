(defn grade-band [score]
  (let [ones (mod score 10)]
    (cond
      (< score 60)    ""        ;; no band for F
      (<= ones 2)     "-"
      (>= ones 7)     "+"