(defn add-score [scores s]
  (conj scores s))