(defn sum-to [n]
  (loop [i 1