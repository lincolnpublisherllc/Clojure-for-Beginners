(defn prompt-add [scores]
  (println "Enter score 0 to 100:")
  (flush)
  (if-let [n (parse-score (read-line))]
    (do (println "Added" n) (add-score scores n))
    (do (println "Invalid score") scores)))