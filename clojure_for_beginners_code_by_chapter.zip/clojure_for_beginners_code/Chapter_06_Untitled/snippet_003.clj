(if false "yes")
;; => nil