(def m {:a 1})
(def m2 (assoc m :b 2))