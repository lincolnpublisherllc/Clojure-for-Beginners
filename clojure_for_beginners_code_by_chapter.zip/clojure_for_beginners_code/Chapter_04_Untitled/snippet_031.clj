(defn profile-line [{:keys [name age status]}]
  (format "%s | age: %d | status: %s" name age status))