(if 0 "truthy" "falsey")      ;; => "truthy"
(if "" "truthy" "falsey")     ;; => "truthy"
(if nil "truthy" "falsey")    ;; => "falsey"