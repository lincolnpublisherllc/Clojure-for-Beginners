;; Avoid
(defn tax-bad [subtotal rate]
  (println (* subtotal rate)) ; side effect here