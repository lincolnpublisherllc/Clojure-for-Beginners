  (println "Area:" area))
;; prints: Area: 78.53975