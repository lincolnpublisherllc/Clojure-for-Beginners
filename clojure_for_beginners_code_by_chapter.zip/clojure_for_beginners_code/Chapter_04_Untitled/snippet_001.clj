(def pi 3.14159)
(def greeting "Hello")