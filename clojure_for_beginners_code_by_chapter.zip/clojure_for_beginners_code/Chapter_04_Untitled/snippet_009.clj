(def nums [1 2 3])
(def nums2 (conj nums 4))