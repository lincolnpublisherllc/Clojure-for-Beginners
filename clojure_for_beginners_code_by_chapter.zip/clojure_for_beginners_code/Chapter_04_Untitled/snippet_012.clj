;; Java parsing for safety
(Long/parseLong "123")     ;; => 123
(Double/parseDouble "2.5") ;; => 2.5