;; Prefer
(defn tax [subtotal rate] (* subtotal rate))
(println (tax 100 0.07))