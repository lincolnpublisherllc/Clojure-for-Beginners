(def person {:name "Ada" :age 30})
(:name person)            ;; => "Ada"
(get person :age)         ;; => 30