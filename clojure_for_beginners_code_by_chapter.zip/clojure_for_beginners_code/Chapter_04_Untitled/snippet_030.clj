(defn full-name [{:keys [first last]}]
  (str/trim (str first " " last)))