(println {:a 1 :b 2})   ;; { :a 1, :b 2 } plus newline (spacing may vary)
(prn {:a 1 :b 2})       ;; prints with quotes/escapes so it can be read back