(prn "line\nbreak")    ;; prints "line\nbreak"
(println "line\nbreak") ;; prints a real line break