(str/upper-case "Ada")              ;; => "ADA"
(str/lower-case "Bo")               ;; => "bo"
(str/split "a,b,c" #",")            ;; => ["a" "b" "c"]
(str/join " | " ["x" "y" "z"])      ;; => "x | y | z"
(str/includes? "Clojure" "j")       ;; => true