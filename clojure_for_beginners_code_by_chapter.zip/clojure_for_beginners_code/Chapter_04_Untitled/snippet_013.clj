(str "Hello, " "Clojure")           ;; => "Hello, Clojure"
(.substring "functional" 0 4)       ;; => "func"
(format "Total: $%.2f" 12.3456)     ;; => "Total: $12.35"