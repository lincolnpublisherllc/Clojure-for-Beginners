(defn run [{:keys [first last age active?]}]
  (let [age-num  (Long/parseLong (str age))