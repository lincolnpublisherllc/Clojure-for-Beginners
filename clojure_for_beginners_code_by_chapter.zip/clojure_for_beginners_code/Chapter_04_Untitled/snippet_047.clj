(defn line->string [{:keys [sku title qty unit] :as line}]
  (format "%-10s | %-20s | %3d × $%5.2f = $%6.2f"
          (name sku) title qty unit (price qty unit)))