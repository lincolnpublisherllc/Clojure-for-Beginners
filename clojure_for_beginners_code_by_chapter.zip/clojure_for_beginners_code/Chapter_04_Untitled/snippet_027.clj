(defn -main [& args]
  (let [name (or (first args) "World")]
    (println "Hello," name)))