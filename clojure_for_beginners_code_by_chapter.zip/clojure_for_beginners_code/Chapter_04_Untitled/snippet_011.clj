(number? 3.0)     ;; => true
(integer? 3)      ;; => true
(rational? 1/3)   ;; => true