(ns play.cards
  (:require [clojure.string :as str]))