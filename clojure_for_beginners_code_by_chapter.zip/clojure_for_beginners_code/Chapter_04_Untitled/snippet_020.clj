(boolean? true)     ;; => true
(nil? nil)          ;; => true
(some? nil)         ;; => false
(empty? [])         ;; => true