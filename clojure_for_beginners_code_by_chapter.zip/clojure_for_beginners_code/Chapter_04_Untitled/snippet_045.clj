(defn price [qty unit]
  (* qty unit))