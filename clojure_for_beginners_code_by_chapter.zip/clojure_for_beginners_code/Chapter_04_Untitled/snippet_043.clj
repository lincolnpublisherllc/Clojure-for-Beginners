;; Build a display label from a map, handling missing keys
(defn label [{:keys [id title] :as m}]
  (str "[" (or id "—") "] " (or title "<untitled>") " " (pr-str (dissoc m :id :title))))