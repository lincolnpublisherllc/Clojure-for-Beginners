(spit "greet.txt" "Hello, file!")
(slurp "greet.txt")   ;; => "Hello, file!"