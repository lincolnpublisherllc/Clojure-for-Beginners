(keyword "user" "id")  ;; => :user/id
(name :user/id)        ;; => "id"
(namespace :user/id)   ;; => "user"