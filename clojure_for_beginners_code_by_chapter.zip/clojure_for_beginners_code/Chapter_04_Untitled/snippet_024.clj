(defn ask-age []
  (println "Enter your age:")
  (flush)                          ;; ensure prompt appears before waiting
  (let [s (read-line)