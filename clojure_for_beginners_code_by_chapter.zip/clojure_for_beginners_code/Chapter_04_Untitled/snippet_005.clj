(defn circle-area [r]
  (let [pi 3.14159]           ;; local pi shadowing any top-level pi
    (* pi r r)))