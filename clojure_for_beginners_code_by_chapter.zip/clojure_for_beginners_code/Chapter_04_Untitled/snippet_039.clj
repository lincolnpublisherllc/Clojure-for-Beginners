(let [n (Long/parseLong (read-line))]
  (inc n))