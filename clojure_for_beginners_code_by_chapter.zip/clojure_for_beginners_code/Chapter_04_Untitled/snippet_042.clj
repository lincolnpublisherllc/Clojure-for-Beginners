;; Toggle a boolean status
(defn toggle [b] (not b))