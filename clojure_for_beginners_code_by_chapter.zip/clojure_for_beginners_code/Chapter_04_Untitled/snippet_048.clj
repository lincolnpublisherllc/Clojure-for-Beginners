(defn run [{:keys [sku title qty unit]}]
  (-> {:sku sku :title title :qty qty :unit unit}