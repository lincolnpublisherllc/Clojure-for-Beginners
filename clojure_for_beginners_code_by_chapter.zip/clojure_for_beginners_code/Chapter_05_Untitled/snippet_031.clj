(defn lcm [a b]
  (if (or (zero? a) (zero? b)) 0 (quot (* (Math/abs a) (Math/abs b)) (gcd a b))))