(Math/sqrt 49)           ;; => 7.0
(Math/pow 2 10)          ;; => 1024.0
(Math/round 2.6)         ;; => 3
(Math/floor 2.9)         ;; => 2.0
(Math/ceil  2.1)         ;; => 3.0