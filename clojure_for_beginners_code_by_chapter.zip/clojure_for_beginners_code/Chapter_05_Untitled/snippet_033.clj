(defn miles->km [m] (* 1.60934 m))
(defn c->f [c] (+ (* 9/5 c) 32))
(defn f->c [f] (* 5/9 (- f 32)))