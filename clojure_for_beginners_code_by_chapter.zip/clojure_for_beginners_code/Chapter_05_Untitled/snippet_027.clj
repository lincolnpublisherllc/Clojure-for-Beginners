(defn mode [xs]
  (when (seq xs)
    (->> xs
         (frequencies)
         (reduce (fn [[best-k best-n] [k n]]
                   (if (> n best-n) [k n] [best-k best-n]))