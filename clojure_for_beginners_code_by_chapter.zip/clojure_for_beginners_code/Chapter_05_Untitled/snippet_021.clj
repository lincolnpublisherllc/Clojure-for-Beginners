(clamp 120 0 100)  ;; => 100
(defn percent [part total]
  (if (pos? total)
    (* 100.0 (/ part total))