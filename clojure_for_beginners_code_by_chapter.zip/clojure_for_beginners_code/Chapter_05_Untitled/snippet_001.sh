clj -X:calc
clj -X:calc :op '"mul"'  :args '["2" "3" "5"]'
clj -X:calc :op '"mean"' :args '["10" "20" "30"]'
clj -X:calc :op '"sub"'  :args '["10" "4"]'