(defn round2 [x]
  (/ (Math/round (* x 100.0)) 100.0))