(= {:a 1 :b 2} {:b 2 :a 1})   ;; => true (maps ignore key order)
(= [1 2 3] [1 2 3])           ;; => true
(= [1 2] '(1 2))              ;; => true (same sequence elements)