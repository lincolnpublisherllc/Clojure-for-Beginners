(parse-long* "250" 0)  ;; => 250
(parse-long* ""    0)  ;; => 0
(defn clamp [x lo hi]
  (-> x
      (max lo)
      (min hi)))