(->> ["a" "b" "c"]
     (map clojure.string/upper-case)
     (clojure.string/join ", "))