(defn median [xs]
  (let [v (vec (sort xs))