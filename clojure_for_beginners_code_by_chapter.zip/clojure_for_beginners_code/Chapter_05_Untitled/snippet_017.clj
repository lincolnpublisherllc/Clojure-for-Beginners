     (str "!"))
;; same as (str (clojure.string/upper-case "clojure") "!")