;; Default when nil
(or nil "fallback")     ;; => "fallback"