(defn mean [xs]
  (if (seq xs)
    (/ (reduce + xs) (count xs))