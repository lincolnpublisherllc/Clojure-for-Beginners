    (cond
      (zero? n) 0
      (odd? n)  (v mid)