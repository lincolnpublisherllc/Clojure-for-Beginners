(= 3 3)          ;; => true
(not= 3 4)       ;; => true
(< 1 2 3)        ;; => true
(<= 2 2 3)       ;; => true
(> 5 4 1)        ;; => true
(>= 3 3 1)       ;; => true