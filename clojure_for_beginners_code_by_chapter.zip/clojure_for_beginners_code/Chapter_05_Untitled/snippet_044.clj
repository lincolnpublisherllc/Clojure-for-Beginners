(defn run [{:keys [op args]}]
  (let [xs (parse-doubles args)