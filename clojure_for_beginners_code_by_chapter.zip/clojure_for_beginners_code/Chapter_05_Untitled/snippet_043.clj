(defn parse-doubles [sv]
  (mapv #(Double/parseDouble %) sv))