(quot 10 3)     ;; => 3    ; truncates toward zero
(rem 10 3)      ;; => 1
(mod 10 3)      ;; => 1    ; like rem, but always non-negative for positive divisor