(defn parse-long* [s default]
  (try
    (Long/parseLong (str s))
    (catch Exception _ default)))