;; Guarded access
(def data {:user {:name "Ada"}})
(and data (:user data) (:name (:user data))) ;; => "Ada"