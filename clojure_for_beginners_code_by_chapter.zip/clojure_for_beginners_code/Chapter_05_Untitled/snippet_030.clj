(fact 10)   ;; => 3628800N
(defn gcd [a b]
  (if (zero? b) (Math/abs a) (recur b (mod a b))))