(ns calc.core
  (:require [clojure.string :as str]))