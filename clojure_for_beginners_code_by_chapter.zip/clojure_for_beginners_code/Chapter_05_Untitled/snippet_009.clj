(and true true)     ;; => true
(and true false)    ;; => false
(or  false "x")     ;; => "x"   ; returns the first truthy value
(or  "x"   "y")     ;; => "x"
(not true)          ;; => false