              ;; default
              (str "Unknown op: " op))]
    (println out)))