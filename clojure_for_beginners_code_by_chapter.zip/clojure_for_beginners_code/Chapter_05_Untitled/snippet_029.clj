(defn fact [n]
  (reduce *' 1N (range 1 (inc n))))  ;; *' handles big numbers